from django.db import models

class GestionProduit(models.Model):
    id = models.UUIDField(primary_key=True, default=models.UUIDField, editable=False)
    description = models.TextField()
    prix = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['created_at']
    def __str__(self):
        return f"Produit {self.description} - Prix: {self.prix}"
    
    